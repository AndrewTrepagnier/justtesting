(function ($) {
    "use strict";

$(document).ready(function(){
    // Target your .container, .wrapper, .post, etc.
    $(".post-list").fitVids();


  });

}(jQuery));
