

from django.contrib import admin

from .models import HomePage

admin.site.register(HomePage)